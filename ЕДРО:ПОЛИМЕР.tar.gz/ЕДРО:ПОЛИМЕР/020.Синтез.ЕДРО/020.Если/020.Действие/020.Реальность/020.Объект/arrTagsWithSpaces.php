#!/usr/bin/php
<?php
//© A.A.CheckMaRev assminog@gmail.com
//Континентальный челябинск.
$мНеделимыеФразы		=json_encode(
	array(
		'In trance we trust', 'we in overdose', 'top 40'
	)
);
$мСловаСАпострофомВместоПробела	=json_encode(
	array(
		'D n B', 'Drum and Base', 'Drum n Base', 'we in overdose', 'top 40'
	)
);
file_put_contents('.CreatorTypes.json', $strCreatorTypes);
?>

