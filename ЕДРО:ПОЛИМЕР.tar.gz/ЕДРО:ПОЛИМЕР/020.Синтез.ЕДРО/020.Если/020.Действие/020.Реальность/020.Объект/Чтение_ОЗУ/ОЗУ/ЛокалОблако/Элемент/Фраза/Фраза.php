<?php
       /*A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru 2020 [25.06.2020]
©//////|   
|_|//|/ /\ 
  //|/<  **> 
 //|/   Jl    
//////| --------------->
||||||/
Благословенный стиль Упрощающий Проверку и Чтение Программы Благословенный.УПИиЧ    */
class Фраза
	{
	public $мСлов;
	public function __construct($_сФраза)
		{
		$сФраза		=$_сФраза;
			   unset($_сФраза);
		$м			=array();
		$сСтрока		=trim($сФраза);
		if(empty($сФраза))
			{
			echo 'Пустая фраза'."\n";
			return $м;
			}
		//if (preg_match('/[\s]+/', $оОбъект->$сСвойство, $arrMatch)==1)
		if(mb_strpos($сФраза, ' ')!==FALSE)
			{
			$мСлов	=explode(' ', $сФраза);
			foreach($мСлов as $сСлово)
				{
				//$strStyle	=strtolower($strStyle);
				if(empty($сСлово))
					{
					echo 'Во время разбора фразы, получили пустое слово!'."\n";
					}
				else
					{
					$м[]	=mb_strtolower($сСлово);
					}
				}
			}
		else
			{
			if(empty($сФраза))
				{
				echo 'Фраза содержит меньше одного слова. Она пуста!'."\n";
				}
			else
				{
				//$arr[]		=strtolower($objStation->genre);
				$м[]		=mb_strtolower($сФраза);
				}
			}
		$this->мСлов	=$м;
		}
	public static function мСлов($_сФраза)
		{
		$мСлов	=array();
		if(empty($_сФраза))
			{
			echo 'Фраза пуста.'."\n";
			}
		else
			{
			$оФраза		=new Фраза($_сФраза);
			if(empty($оФраза->мСлов))
				{
				echo 'Массив слов пуст'."\n";
				}
			else
				{
				$мСлов	=$оФраза->мСлов;
				}
			}
		return $мСлов;
		}
	}
?>
