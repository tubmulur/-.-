<?php
    /*
© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru 2020 [25.06.2020]
//////|
|_|//|/ /\  
  //|/<  **> 
 //|/   Jl   
//////| --------------->
||||||/
Благословенный стиль Упрощающий Проверку и Чтение Программы Благословенный.УПИиЧ*/
class Действие extends Реальность
	{
	public function __construct()
		{
		parent::__construct();
		}
	}
?>
