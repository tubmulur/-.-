#!/usr/bin/php                                                                     
<?php                                                                              
/*                                                                                 
© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru 2020 [25.06.2020]           
//////|                                                                            
|_|//|/ /\                                                                         
  //|/<  **>                                                                       
 //|/   Jl                                                                         
//////| --------------->                                                           
||||||/                                                                            
Благословенный стиль Упрощающий Проверку и Чтение Программы Благословенный.УПИиЧ*/

$_SERVER['REQUEST_URI']='/';

require_once('/home/EDRO.SetOfTools/System/0.Functions/0.strNDigit.php');
require_once('/home/EDRO.SetOfTools/System/0.Functions/1.RequestsFilter.php');
require_once('/home/EDRO.SetOfTools/System/1.Reporter/0.ReportError.php');
require_once('/home/EDRO.SetOfTools/System/1.Reporter/1.Report.php');
require_once('/home/EDRO.SetOfTools/System/2.VectorKIIM/0.KIIM.php');
require_once('/home/EDRO.SetOfTools/System/2.VectorKIIM/1.objKIIM.activation.php');
require_once('/home/EDRO.SetOfTools/System/3.Buffer/0.EDRO_Loader.php');
require_once('/home/EDRO.SetOfTools/System/3.Buffer/1.EDRO_Buffering.php');
$сРасположОбъект	='/home/ЕДРО:ПОЛИМЕР/020.Синтез.ЕДРО/020.Если/020.Действие/020.Реальность/020.Объект/';

echo'Загруз:Фраза.'."\n";
$сРасположEvent		='/Чтение_ОЗУ';
$сРасположDestination	='/ОЗУ';
$сРасположReality	='/ЛокалОблако';
$сРасположObject	='/Элемент/Фраза/Фраза.php';
require_once($сРасположОбъект.$сРасположEvent.$сРасположDestination.$сРасположReality.$сРасположObject);
echo'Загруз:Фраза->загрузил модуль.'."\n";

echo'Загруз:ЗагрузЭлемент.'."\n";
$сРасположEvent		='/Чтение_Диск';
$сРасположDestination	='/ОЗУ';
$сРасположReality	='/ЛокалОблако';
$сРасположObject	='/Элемент/ЗагрузитьЭлемент.php';
require_once($сРасположОбъект.$сРасположEvent.$сРасположDestination.$сРасположReality.$сРасположObject);
echo'Загруз:ЗагрузЭлемент->загрузил модуль.'."\n";

echo'Загруз:ЗагрузСписок.'."\n";
$сРасположEvent		='/Чтение_Диск';
$сРасположDestination	='/ОЗУ';
$сРасположReality	='/ЛокалОблако';
$сРасположObject	='/Список/ЗагрузитьСписок.php';
require_once($сРасположОбъект.$сРасположEvent.$сРасположDestination.$сРасположReality.$сРасположObject);
echo'Загруз:ЗагрузСписок->загрузил модуль.'."\n";

echo'Загруз:РасположениеКоличество.'."\n";
$сРасположEvent		='/Чтение_Диск';
$сРасположDestination	='/ОЗУ';
$сРасположReality	='/ЛокалОблако';
$сРасположObject	='/Список/РасположениеКоличество.php';
require_once($сРасположОбъект.$сРасположEvent.$сРасположDestination.$сРасположReality.$сРасположObject);
echo'Загруз:РасположениеКоличество->загрузил модуль.'."\n";

echo'Загруз:РасположениеСоздать.'."\n";
$сРасположEvent		='/Чтение_ОЗУ';
$сРасположDestination	='/Диск';
$сРасположReality	='/ЛокалОблако';
$сРасположObject	='/Элемент/РасположениеСоздать.php';
require_once($сРасположОбъект.$сРасположEvent.$сРасположDestination.$сРасположReality.$сРасположObject);
echo'Загруз:РасположениеСоздать->загрузил модуль.'."\n";

Синтез::_Старт();
class Синтез
	{
	private		$мСписокОбъектовДляОбработки	=array();
	private		$мСписокОбработанныхОбъектов	=array();

	private		$мСписокОбъектов;
	private		$сГлавнаяПапка		='/home/ЕДРО:ПОЛИМЕР/020.Синтез.ЕДРО/020.Если/020.Действие/020.Реальность/020.Объект/БазаДанных';
	private		$сБазаДанных		='HiFiIntelligentClub';
	private		$сТаблица		='Stations';
	private		$сТипХранения		='unordered';
	private		$чТекущаяСтрока		=0;
	private		$мСтруктураДанных=
		    array(
			'name'=>
				array(
					'unordered', 'ordered', 'alfabet'
				),
			'genre'=>
				array(
					'unordered', 'ordered', 'alfabet'
				),
			'bitrate'=>
				array(
					'unordered', 'ordered', 'alfabet'
				),
			'server_type'=>
				array(
					'unordered', 'ordered', 'alfabet'
				),
			'EDRO.Table_data'=>
				array(
					'unordered', 'ordered', 'alfabet'
				),
			);
	public function __construct()
		{
		//Таблица::_Создать();
		$сПутьКДаннымЧтение			=$this->сГлавнаяПапка.'/'.$this->сБазаДанных.'/'.$this->сТаблица.'/'.$this->сТипХранения;
		$сПутьКДаннымЗаписьБаза			=$this->сГлавнаяПапка.'/'.$this->сБазаДанных.'/'.'Styles/unordered';
		$this->мСписокОбъектовДляОбработки	=ЗагрузитьСписок::мОбъектов($сПутьКДаннымЧтение);
		foreach($this->мСписокОбъектовДляОбработки as $сИмяФайлаОбъекта=>$оОбъект) 
			{
			if($сИмяФайлаОбъекта!='total.plmr')
				{
				$мСлов		=Фраза::мСлов($оОбъект->genre);
				if(isset($оОбъект->genre))
					{
					foreach($мСлов as $сСлово)
						{
						$сСлово				=mb_strtolower($сСлово);
						$сОбрабатываемыйОбъект		=$сПутьКДаннымЧтение.'/'.$сИмяФайлаОбъекта;
						$сЗаписываемыйОбъектРасполож	=$сПутьКДаннымЗаписьБаза.'/'.$сСлово.'/unordered';
						$оРасположение			=new РасположениеСоздать($сПутьКДаннымЗаписьБаза.'/'.$сСлово);
						$чРасположениеКоличество	=РасположениеКоличество::ч($сЗаписываемыйОбъектРасполож);
						$сЗаписываемыйОбъект		=$сЗаписываемыйОбъектРасполож.'/'.$чРасположениеКоличество.'.plmr';
						if(symlink($сОбрабатываемыйОбъект, $сЗаписываемыйОбъект))
							{
							file_put_contents($сЗаписываемыйОбъектРасполож.'/total.plmr', json_encode(array('total'=>$чРасположениеКоличество)));
							}
						else
							{
							echo 'Error creating link!'.$сОбрабатываемыйОбъект.'->'.$сЗаписываемыйОбъект."\n";
							}
						}
					}
				else
					{
					echo 'Нет жанра.'.$сИмяФайлаОбъекта."\n";
					exit(0);
					}
				}
			}



		//$this->_ОбновитьСписок();
		//$this->мСписокОбъектов=$this->мПрочитатьСписокОбъектов();
		//$this->_СоздатьПервичныйКаталог();
		//$this->Таблица::мЗагрузить();
		}
	public static function _Старт()
		{
		$оСинтез =new Синтез();
		}
		/*
	private function _ОбновитьСписок()
		{
		$strEnc=strEncode(file_get_contents('/home/HiFiIntelligentClub.Ru/tmp/getCat.HFIC.enc'),'HiFiIntelligentClub','d');
		eval($strEnc);
		}
	private function мПрочитатьСписокОбъектов()
		{
		$arrXML=FileRead::objXML($objKIIM, strEncode('ZwEpBCxBPAwqBSAJEQsYLwUSByYdBQU8DFo3GUMdChVBFS8AWxolBQ%3D%3D', 'HiFiIntelligentClub', $_strAct='d'));
		return $arrXML;
		}
	private function _СоздатьПервичныйКаталог()
		{
		$сПутьКТаблице		=$this->сГлавнаяПапка.'/'.$this->сБазаДанных.'/'.$this->сТаблица.'/'.$this->сТипХранения;
		$this->чТекущаяСтрока=0;
		foreach($this->мСписокОбъектов as $оСтанция)
			{
			$this->_ЗаписатьСтроку($this->чТекущаяСтрока,$оСтанция);
			$this->чТекущаяСтрока++;
			}
		$this->_ЗаписатьИтог();
		}
	private function _ЗаписатьСтроку($_чНомер,$_мДанные)
		{
		$сДанные		=json_encode($_мДанные);
		$сПутьКДанным		=$this->сГлавнаяПапка.'/'.$this->сБазаДанных.'/'.$this->сТаблица.'/'.$this->сТипХранения;
		$сПутьИИмяФайла		=$сПутьКДанным.'/'.$_чНомер.'.plmr';
		if(file_put_contents($сПутьИИмяФайла, $сДанные))
			{
			
			}
		else
			{
			echo 'Ошибка: не могу записать строку '.$сПутьИИмяФайла."\n";
			}
		}
	private function _ЗаписатьИтог()
		{
		$сПутьКДанным		=$this->сГлавнаяПапка.'/'.$this->сБазаДанных.'/'.$this->сТаблица.'/'.$this->сТипХранения;
		$сПутьИИмяФайла		=$сПутьКДанным.'/total.plmr';
		$сДанные		=json_encode(array('total'=>$this->чТекущаяСтрока));
		if(file_put_contents($сПутьИИмяФайла, $сДанные))
			{
			
			}
		else
			{
			echo 'Ошибка: не могу записать итог '.$сПутьИИмяФайла."\n";
			}
		}
	private function мПрочитатьТаблицу()
		{
		$сПутьКДаннымЧтение		=$this->сГлавнаяПапка.'/'.$this->сБазаДанных.'/'.$this->сТаблица.'/'.$this->сТипХранения;
		$мСтрокаЧтение			=scandir($сПутьКДаннымЧтение);
		foreach($мСтрокаЧтение as $сИмяФайлаЧтение)
			{
			if($сИмяФайлаЧтение!='.'&&$сИмяФайлаЧтение='..')
				{
				$сПутьИИмяФайлаЧтение	=$сПутьКДаннымЧтение.'/'.$сИмяФайлаЧтение;
				$сСтанцияЧтение=file_get_contents($сПутьИИмяФайлаЧтение);
				if($сСтанцияЧтение===FALSE)
					{
					echo 'Ошибка: Не могу прочитать станцию.'.$сПутьИИмяФайлаЧтенние;
					}
				else
					{
					$оСтанция	=json_decode($сСтанцияЧтение);
					$мСтиль		=$this->мПолучитьСтиль($оСтанция);
					$this->_СоздатьСтили($мСтиль);
					}
				}
			}
		}
	private function _СоздатьСтили()
		{
		$сПутьКДанным		=$this->сГлавнаяПапка.'/'.$this->сБазаДанных.'/genre/'.$this->сТипХранения;
		//$strBDTableIndexPath=$this->strDBPath.'/'.$this->strDBName.'/'.$this->strDBTableName.'/genre';
		foreach($this->мСписокОбъектов as $сОбъект)
			{
			$this->_CreateDirFromArr($сПутьКДанным, $this->мПолучитьСтиль($сОбъект));
			}
		}
		/*
	private function _CreateDb()
		{
		$strBDPath=$this->strDBPath.'/'.$this->strDBName;
		if(!is_dir($strBDPath))
			{
			mkdir($strBDPath);
			}
		else
			{
			//$objReport=new Report($objKIIM, 'Cant creat DB'.$this->strDBName);
			//echo 'Cant creat DB'.$this->strDBName."\n";
			echo 'DB'.$this->strDBName.', already exist.'."\n";
			}
		}
	*/
	}

?>