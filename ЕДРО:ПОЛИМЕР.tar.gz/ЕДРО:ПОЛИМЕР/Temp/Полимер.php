<?php
        /*
© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru 2020 [25.06.2020]
//////|
|_|//|/ /\  
  //|/<  **> 
 //|/   Jl    
//////| --------------->
||||||/
Благословенный стиль Упрощающий Проверку и Чтение Программы Благословенный.УПИиЧ*/
require_once('/home/EDRO.SetOfTools/System/0.Functions/0.strNDigit.php');
require_once('/home/EDRO.SetOfTools/System/1.Reporter/0.ReportError.php');
require_once('/home/EDRO.SetOfTools/System/1.Reporter/1.Report.php');
require_once('/home/ЕДРО:ПОЛИМЕР/Temp/1.Если.php');
require_once('/home/ЕДРО:ПОЛИМЕР/Temp/2.Действие.php');
require_once('/home/ЕДРО:ПОЛИМЕР/Temp/3.Реальность.php');
require_once('/home/ЕДРО:ПОЛИМЕР/Temp/4.Объект.php');

$оПолимер				=ЕДРО::Синтез();

class ЕДРО
	{
	public		$оЕДРО			=(object)array();
	protected 	$сРасполож		='/home/ЕДРО.Полимер/';
	protected 	$сПроект		='/HiFiIntelligentClub/';
	protected 	$сДействиеПоУмолчанию	='1.Чтение';
	protected 	$сВходящийЕсли;
	public function __construct()
		{
		$this->оЕДРО=new Если();
		}
	public static function Синтез()
		{
		$оПолимер = new ЕДРО();
		}
	}
?>



//  [П]=Синтез[ЕДРО]